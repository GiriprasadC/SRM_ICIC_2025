
        // Set the target date
        const targetDate = new Date("March 10, 2025 00:00:00").getTime();

        // Update the countdown every second
        const countdownTimer = setInterval(function() {
            const now = new Date().getTime();
            const timeLeft = targetDate - now;

            // Calculate days, hours, minutes, and seconds
            const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
            const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

            // Display the result in the "countdown-timer" element
            document.getElementById("countdown-timer").innerHTML = `${days}d ${hours}h ${minutes}m ${seconds}s`;

            // If the countdown is finished, display a message
            if (timeLeft < 0) {
                clearInterval(countdownTimer);
                document.getElementById("countdown-timer").innerHTML = "Event Started!";
            }
        }, 1000);
        // Show the popup when the page is loaded
// Wait until the page is fully loaded
window.onload = function() {
  var loader = document.getElementById('loader');
  var content = document.getElementById('content');
  var popupBox = document.getElementById('popup-box');
  var closeButton = document.getElementById('close-btn');

  // Hide the loader after the page is loaded
  loader.style.display = 'none';
  content.style.display = 'block'; // Show the content
  
  // Handle the "OK" button to hide the popup
  closeButton.addEventListener('click', function() {
    popupBox.style.display = 'none'; // Hide the popup
  });
};


